﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankManagementSystem.ViewModel;
using BankManagementSystem.Model;
using CS.ViewModel.Handler;
using System.Windows;
using BankManagementSystem.ViewModel.Helper;
using Moq;
using BankManagementSystemTest.ViewModelTest.Handler;

namespace BankManagementSystemTest.ViewModelTest
{
    [TestFixture]
    public class UserDetailsVMTest
    {
        User user;
        UserDetailsVM userDetailsVM;
        private Mock<ILoginHandler> mockLoginHandler;

        public UserDetailsVMTest()
        {
            user = TestData.UserDetail;


        }

        [SetUp]
        public void Setup()
        {
            userDetailsVM = new UserDetailsVM();
            mockLoginHandler = new Mock<ILoginHandler>();
            userDetailsVM.LoginHandler= mockLoginHandler.Object;
            mockLoginHandler.Setup(x => x.GetUser(It.IsAny<int>()))
                .ReturnsAsync(new User()
                {
                    UserId = user.UserId,
                    UserName = user.UserName,
                    Password = user.Password,
                    Name = user.Name,
                    Address = user.Address,
                    State = user.State,
                    ContactNo = user.ContactNo,
                    County = user.County,
                    PAN = user.PAN,
                    DOB = user.DOB,
                    AccountType = user.AccountType
                });
            mockLoginHandler.Setup(x => x.UpdateUser(It.IsAny<User>()))
                .ReturnsAsync(new User()
                {
                    UserId = user.UserId,
                    UserName = user.UserName,
                    Password = user.Password,
                    Name = user.Name,
                    Address = user.Address,
                    State = user.State,
                    ContactNo = user.ContactNo,
                    County = user.County,
                    PAN = user.PAN,
                    DOB = user.DOB,
                    AccountType = user.AccountType
                });
        }

        [Test]
        public async Task Get_User_Valid_TestAsync()
        {
            UserDate.UserID = 1;
            userDetailsVM.GetUser();
            Assert.AreEqual(userDetailsVM.Username, user.UserName);
        }

        [Test]
        public async Task Get_User_InValid_TestAsync()
        {
            UserDate.UserID=0;
            userDetailsVM.GetUser();
            Assert.AreNotEqual(userDetailsVM.Username, user.UserName);
        }

        [Test]
        public async Task Update_User_Valid_TestAsync()
        {
            userDetailsVM.UpdateUser(user);
            Assert.AreEqual(user.Name, userDetailsVM.Name);
        }


    }

}
