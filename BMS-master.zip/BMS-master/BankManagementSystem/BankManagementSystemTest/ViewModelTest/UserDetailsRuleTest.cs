﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankManagementSystem.ViewModel;
using System.Windows.Controls;
using Newtonsoft.Json.Linq;


namespace BankManagementSystemTest.ViewModelTest
{
    [TestFixture]
    public class UserDetailsRuleTest
    {
        CultureInfo cultureInfo;
        UserDetailsRule UserDetailsRule;
        public UserDetailsRuleTest()
        {
            cultureInfo= CultureInfo.InvariantCulture;
            UserDetailsRule= new UserDetailsRule();
        }
        [Test]
        [TestCase("Name", "Nitin ")]
        public void NameValidTest(string type, string value)
        {
            UserDetailsRule.name = type;
            ValidationResult val =UserDetailsRule.Validate(value,cultureInfo);
            Assert.IsTrue(val.IsValid);
        }
        [Test]
        [TestCase("Name","Bhagyashree1")]
        [TestCase("Name", "@#$%")]
        public void NameInValidTest(string type, string value)
        {
            UserDetailsRule.name = type;
            ValidationResult val = UserDetailsRule.Validate(value, cultureInfo);
            Assert.IsFalse(val.IsValid);
        }
        [Test]
        [TestCase("Username", "bhagu1234")]
        public void UserNameValidTest(string type, string value)
        {
            UserDetailsRule.name = type;
            ValidationResult val = UserDetailsRule.Validate(value, cultureInfo);
            Assert.IsTrue(val.IsValid);
        }
        [Test]
        [TestCase("Username", "bhagu")]
        [TestCase("Username", "bhagu@123")]
        public void UserNameInValidTest(string type, string value)
        {
            UserDetailsRule.name = type;
            ValidationResult val = UserDetailsRule.Validate(value, cultureInfo);
            Assert.IsFalse(val.IsValid);
        }
        [Test]
        [TestCase("Password", "Avin@sh2022")]
        public void PasswordValidTest(string type, string value)
        {
            UserDetailsRule.name = type;
            ValidationResult val = UserDetailsRule.Validate(value, cultureInfo);
            Assert.IsTrue(val.IsValid);
        }
        [Test]
        [TestCase("Password", "Avi@22")]
        [TestCase("Password", "Bhagu1996")]
        [TestCase("Password", "bhagu@1996")]
        [TestCase("Password", "Bhagy@shree")]
        public void PasswordInValidTest(string type, string value)
        {
            UserDetailsRule.name = type;
            ValidationResult val = UserDetailsRule.Validate(value, cultureInfo);
            Assert.IsFalse(val.IsValid);
        }
        [Test]
        [TestCase("Email", "bhagu@abc.com")]
        public void EmailValidTest(string type, string value)
        {
            UserDetailsRule.name = type;
            ValidationResult val = UserDetailsRule.Validate(value, cultureInfo);
            Assert.IsTrue(val.IsValid);
            }
        [Test]
        [TestCase("Email", "Avi@abc")]
        [TestCase("Email", "bhagu.com")]
        public void EmailInValidTest(string type, string value)
        {
            UserDetailsRule.name = type;
            ValidationResult val = UserDetailsRule.Validate(value, cultureInfo);
            Assert.IsFalse(val.IsValid);
        }
        [Test]
        [TestCase("Address", "Shivaji Chowk, Kalyan")]
        [TestCase("Address", "kalyan421301")]
        public void AddressValidTest(string type, string value)
        {
            UserDetailsRule.name = type;
            ValidationResult val = UserDetailsRule.Validate(value, cultureInfo);
            Assert.IsTrue(val.IsValid);
        }
        [Test]
        [TestCase("Address", "")]
        public void AddressInValidTest(string type, string value)
        {
            UserDetailsRule.name = type;
            ValidationResult val = UserDetailsRule.Validate(value, cultureInfo);
            Assert.IsFalse(val.IsValid);
        }
        [Test]
        [TestCase("State", "kalyan421301")]
        public void StateValidTest(string type, string value)
        {
            UserDetailsRule.name = type;
            ValidationResult val = UserDetailsRule.Validate(value, cultureInfo);
            Assert.IsTrue(val.IsValid);
        }
        [Test]
        [TestCase("State", "")]
        public void StateInValidTest(string type, string value)
        {
            UserDetailsRule.name = type;
            ValidationResult val = UserDetailsRule.Validate(value, cultureInfo);
            Assert.IsFalse(val.IsValid);
        }
        [Test]
        [TestCase("County", "India")]
        public void CountyValidTest(string type, string value)
        {
            UserDetailsRule.name = type;
            ValidationResult val = UserDetailsRule.Validate(value, cultureInfo);
            Assert.IsTrue(val.IsValid);
        }
        [Test]
        [TestCase("County", "")]
        public void CountyInValidTest(string type, string value)
        {
            UserDetailsRule.name = type;
            ValidationResult val = UserDetailsRule.Validate(value, cultureInfo);
            Assert.IsFalse(val.IsValid);
        }
        [Test]
        [TestCase("PAN", "CJPQS67898")]
        public void PANValidTest(string type, string value)
        {
            var UserDetailsRule = new UserDetailsRule();
            UserDetailsRule.name = type;
            ValidationResult val = UserDetailsRule.Validate(value, cultureInfo);
            Assert.IsTrue(val.IsValid);
        }
        [Test]
        [TestCase("PAN", "")]
        [TestCase("PAN", "CJPQS6789")]
        public void PANInValidTest(string type, string value)
        {
            UserDetailsRule.name = type;
            ValidationResult val = UserDetailsRule.Validate(value, cultureInfo);
            Assert.IsFalse(val.IsValid);
        }
        [Test]
        [TestCase("ContactNo", "9423086332")]
        public void ContactNoValidTest(string type, string value)
        {
            UserDetailsRule.name = type;
            ValidationResult val = UserDetailsRule.Validate(value, cultureInfo);
            Assert.IsTrue(val.IsValid);
        }
        [Test]
        [TestCase("ContactNo", "")]
        [TestCase("ContactNo", "CJPQS6789")]
        public void ContactNoInValidTest(string type, string value)
        {
            UserDetailsRule.name = type;
            ValidationResult val = UserDetailsRule.Validate(value, cultureInfo);
            Assert.IsFalse(val.IsValid);
        }
        [Test]
        [TestCase("DOB", "1996-11-27")]
        public void DOBValidTest(string type, string value)
        {
            UserDetailsRule.name = type;
            ValidationResult val = UserDetailsRule.Validate(value, cultureInfo);
            Assert.IsTrue(val.IsValid);
        }
        [Test]
        [TestCase("DOB", "2022-11-27")]
        public void DOBInValidTest(string type, string value)
        {
            UserDetailsRule.name = type;
            ValidationResult val = UserDetailsRule.Validate(value, cultureInfo);
            Assert.IsFalse(val.IsValid);
        }
        [Test]
        [TestCase("LoanAmount", "200000")]
        public void LoanAmountValidTest(string type, string value)
        {
            UserDetailsRule.name = type;
            ValidationResult val = UserDetailsRule.Validate(value, cultureInfo);
            Assert.IsTrue(val.IsValid);
        }
        [Test]
        [TestCase("LoanAmount", "0")]
        public void LoanAmountInValidTest(string type, string value)
        {
            UserDetailsRule.name = type;
            ValidationResult val = UserDetailsRule.Validate(value, cultureInfo);
            Assert.IsFalse(val.IsValid);
        }
        [Test]
        [TestCase("Date", "1996-11-27")]
        public void DateValidTest(string type, string value)
        {
            UserDetailsRule.name = type;
            ValidationResult val = UserDetailsRule.Validate(value, cultureInfo);
            Assert.IsTrue(val.IsValid);
        }
        [Test]
        [TestCase("Date", "2023-12-12")]
        public void DateInValidTest(string type, string value)
        {
            UserDetailsRule.name = type;
            ValidationResult val = UserDetailsRule.Validate(value, cultureInfo);
            Assert.IsFalse(val.IsValid);
        }

        [Test]
        [TestCase("RateOfInterest", "20")]
        public void ROIValidTest(string type, string value)
        {
            UserDetailsRule.name = type;
            ValidationResult val = UserDetailsRule.Validate(value, cultureInfo);
            Assert.IsTrue(val.IsValid);
        }
        [Test]
        [TestCase("RateOfInterest", "")]
        [TestCase("RateOfInterest", "150")]
        public void ROIInValidTest(string type, string value)
        {
            UserDetailsRule.name = type;
            ValidationResult val = UserDetailsRule.Validate(value, cultureInfo);
            Assert.IsFalse(val.IsValid);
        }
        [TestCase("LoanDuration", "20")]
        public void LoanDurationValidTest(string type, string value)
        {
            UserDetailsRule.name = type;
            ValidationResult val = UserDetailsRule.Validate(value, cultureInfo);
            Assert.IsTrue(val.IsValid);
        }
        [Test]
        [TestCase("LoanDuration", "")]
        [TestCase("LoanDuration", "150")]
        public void LoanDurationInValidTest(string type, string value)
        {
            UserDetailsRule.name = type;
            ValidationResult val = UserDetailsRule.Validate(value, cultureInfo);
            Assert.IsFalse(val.IsValid);
        }
    }
}
