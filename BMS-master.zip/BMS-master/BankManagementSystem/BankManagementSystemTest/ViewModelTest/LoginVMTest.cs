﻿using CS.ViewModel.Handler;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankManagementSystem.ViewModel;
using BankManagementSystem.Model;
using System.Windows;
using BankManagementSystem.ViewModel.Helper;
using AutoMapper;
using BankManagementSystem.View;
using BankManagementSystemTest.ViewModelTest.Handler;

namespace BankManagementSystemTest.ViewModelTest
{
    [TestFixture]
    public class LoginVMTest
    {
        LoginVM LoginVM;
        private Mock<ILoginHandler> mockLoginHandler;
        //private Mock<IMapper> mapper;
        User user;
        public LoginVMTest()
        {
            LoginVM= new LoginVM();
            user= TestData.UserDetail;
        }

        [SetUp]
        public void Setup()
        {
            mockLoginHandler = new Mock<ILoginHandler>();
            LoginVM.loginHandler= mockLoginHandler.Object;
            mockLoginHandler.Setup(x => x.AuthUser(It.IsAny<User>()))
                .ReturnsAsync(new User()
                {
                    UserId=user.UserId,
                    UserName=user.UserName,
                    Password=user.Password,
                    Name=user.Name,
                    Address=user.Address,
                    State=user.State,
                    ContactNo=user.ContactNo,
                    County=user.County,
                    PAN=user.PAN,
                    DOB=user.DOB,
                    AccountType=user.AccountType
                });
            
            mockLoginHandler.Setup(x => x.AddUser(It.IsAny<User>()))
                .ReturnsAsync(
                new User()
                {
                    UserId=user.UserId,
                    UserName=user.UserName,
                    Password=user.Password,
                    Name=user.Name,
                    Address=user.Address,
                    State=user.State,
                    ContactNo=user.ContactNo,
                    County=user.County,
                    PAN=user.PAN,
                    DOB=user.DOB,
                    AccountType=user.AccountType
                }
            );


        }

        [Test]
        [TestCase("Bhagu1996","Bhagu@1996")]
        public async Task Valid_Login_TestAsync(string uname,string pwd)
        {
            user.UserName=uname;
            user.Password=pwd;
            LoginVM.Login(user);
            Assert.AreEqual(uname,UserDate.UserName);
            Assert.AreEqual(pwd, UserDate.Password);
        }

        [Test]
        [TestCase("admin2022", "admin@2022")]
        public async Task InValid_Login_TestAsync(string uname, string pwd)
        {
            LoginVM.Username=uname;
            LoginVM.Password=pwd;
            LoginVM.Login(user);
            Assert.AreNotEqual(uname, UserDate.UserName);
            Assert.AreNotEqual(pwd, UserDate.Password);
        }

        [Test]
        public async Task Valid_Register_User_Test()
        {
            LoginVM.Register(user);
            Assert.IsNotNull(LoginVM.test);
        }

        [Test]
        [TestCase("Bhagyashree")]
        public async Task SetUsername_Test(string value)
        {
            LoginVM.Username=value;
            Assert.AreEqual(value,LoginVM.User.UserName);
        }

        [Test]
        [TestCase("Bhagyashree Deshmukh")]
        public async Task SetName_Test(string value)
        {
            LoginVM.Name=value;
            Assert.AreEqual(value, LoginVM.User.Name);
        }

        [Test]
        [TestCase("Bhagu1996")]
        public async Task SetPassword_Test(string value)
        {
            LoginVM.Password=value;
            Assert.AreEqual(value, LoginVM.User.Password);
        }

        [Test]
        [TestCase("CJQPD2345T")]
        public async Task Setpan_Test(string value)
        {
            LoginVM.PAN=value;
            Assert.AreEqual(value, LoginVM.User.PAN);
        }

        [Test]
        [TestCase("2022-12-12")]
        public async Task SetDOB_Test(string val)
        {
            LoginVM.DOB=Convert.ToDateTime(val);
            Assert.AreEqual(Convert.ToDateTime(val), LoginVM.User.DOB);
        }
    }
}
