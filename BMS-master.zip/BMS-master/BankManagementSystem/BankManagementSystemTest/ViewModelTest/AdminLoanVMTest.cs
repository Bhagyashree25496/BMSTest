﻿using BankManagementSystem.Model;
using BankManagementSystem.ViewModel.Helper;
using BankManagementSystem.ViewModel;
using BankManagementSystemTest.ViewModelTest.Handler;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankManagementSystem.ViewModel.AdminVM;

namespace BankManagementSystemTest.ViewModelTest
{
    public class AdminLoanVMTest
    {
        Loan loan;
        AdminLoanVM adminLoanVM;
        private Mock<ILoginHandler> mockLoginHandler;

        public AdminLoanVMTest()
        {
            loan = TestData.Loan;
            adminLoanVM=new AdminLoanVM();
        }

        [SetUp]
        public void Setup()
        {
            mockLoginHandler = new Mock<ILoginHandler>();
            adminLoanVM.loginHandler= mockLoginHandler.Object;
            mockLoginHandler.Setup(x => x.GetLoan())
                .ReturnsAsync(new List<Loan>()
                {
                    new Loan(){LoanId=loan.LoanId,
                    UserId=loan.UserId,
                    LoanAmount=loan.LoanAmount,
                    LoanDuration=loan.LoanDuration,
                    LoanType=loan.LoanType,
                    Date=loan.Date,
                    Comments=loan.Comments,
                    RateOfInterest=loan.RateOfInterest,
                    Status=loan.Status}
                });

        }

        [Test]
        public async Task GetLoan_Test()
        {
            adminLoanVM.GetLoan();
            Assert.IsNotEmpty(adminLoanVM.UserLoan);
        }

        
    }
}
