﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankManagementSystem.ViewModel;
using BankManagementSystem.Model;
using CS.ViewModel.Handler;
using BankManagementSystemTest.ViewModelTest.Handler;
using BankManagementSystem.ViewModel.Helper;
using Moq;

namespace BankManagementSystemTest.ViewModelTest
{
    [TestFixture]
    public class LoanVMTest
    {
        Loan loan;
        AddLoanVM addLoanVM;
        UserLoanVM UserLoanVM;
        private Mock<ILoginHandler> mockLoginHandler;

        public LoanVMTest()
        {
            loan = TestData.Loan;
            addLoanVM=new AddLoanVM();
            UserLoanVM= new UserLoanVM();
        }

        [SetUp]
        public void Setup()
        {
            mockLoginHandler = new Mock<ILoginHandler>();
            addLoanVM.loginHandler= mockLoginHandler.Object;
            mockLoginHandler.Setup(x => x.AddLoan(It.IsAny<Loan>()))
                .ReturnsAsync(new Loan()
                {
                    LoanId=loan.LoanId,
                    UserId=loan.UserId,
                    LoanAmount=loan.LoanAmount,
                    LoanDuration=loan.LoanDuration,
                    LoanType=loan.LoanType,
                    Date=loan.Date,
                    Comments=loan.Comments,
                    RateOfInterest=loan.RateOfInterest,
                    Status=loan.Status

                });
            UserLoanVM.loginHandler=mockLoginHandler.Object;
            mockLoginHandler.Setup(x => x.GetLoanByUserID(It.IsAny<int>()))
                .ReturnsAsync(new List<Loan>()
                {
                    new Loan(){LoanId=loan.LoanId,
                    UserId=loan.UserId,
                    LoanAmount=loan.LoanAmount,
                    LoanDuration=loan.LoanDuration,
                    LoanType=loan.LoanType,
                    Date=loan.Date,
                    Comments=loan.Comments,
                    RateOfInterest=loan.RateOfInterest,
                    Status=loan.Status}
                    

                });
        }

        [Test]
        public async Task AddLoan_Test()
        {
            addLoanVM.AddNewLoan(loan);
            Assert.IsNotNull(addLoanVM.resp);
        }

        [Test]
        public async Task GetLoan_Test()
        {
            UserDate.UserID=1;
            UserLoanVM.GetLoan();
            Assert.AreEqual(UserLoanVM.UserLoan.Count,1);
        }

        [Test]
        [TestCase(20000)]
        public async Task SetLoanAmount_Test(int val)
        {
            addLoanVM.LoanAmount=val;
            Assert.AreEqual(val,addLoanVM.Loan.LoanAmount);
        }

        
        [Test]
        [TestCase(20)]
        public async Task SetLoanDurationt_Test(int val)
        {
            addLoanVM.LoanDuration=val;
            Assert.AreEqual(val, addLoanVM.Loan.LoanDuration);
        }

        [Test]
        [TestCase("2022-12-12")]
        public async Task SetDate_Test(string val)
        {
            addLoanVM.Date=Convert.ToDateTime(val);
            Assert.AreEqual(Convert.ToDateTime(val), addLoanVM.Loan.Date);
        }


    }
}
