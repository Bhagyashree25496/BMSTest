﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankManagementSystem.ViewModel;
using BankManagementSystem.Model;
using CS.ViewModel.Handler;
using BankManagementSystem.ViewModel.Command;
using System.Windows;

namespace BankManagementSystemTest.ViewModelTest.CommandTest
{
    [TestFixture]
    public class UpdateViewCommandTest
    {
        ShowRegisterCommand showRegisterCommand;
        LoginCommand loginCommand;
        LoginVM loginVM;
        public UpdateViewCommandTest()
        {
            loginVM= new LoginVM();
            showRegisterCommand = new ShowRegisterCommand(loginVM);
            loginCommand = new LoginCommand(loginVM);
        }
        [Test]
        public void SwitchRegisterViewCommandTest()
        {
            showRegisterCommand.Execute("");
            Assert.IsTrue(loginVM.RegisterVis == Visibility.Visible);
        }
        [Test]
        public void SwitchLoginViewCommandTest()
        {
            showRegisterCommand.Execute("");
            showRegisterCommand.Execute("");
            Assert.IsTrue(loginVM.LoginVis == Visibility.Visible);
        }
        [Test]
        public void LoginViewCommandTest()
        {
            loginCommand.Execute("");
            Assert.IsNotNull(UserDate.UserID);
        }
    }
}
