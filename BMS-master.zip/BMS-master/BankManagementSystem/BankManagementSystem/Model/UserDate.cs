﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankManagementSystem.Model
{
    public static class UserDate
    {
        public static int UserID;
        public static string UserName;
        public static string Password;
        public static string Role;

        

    }

}
