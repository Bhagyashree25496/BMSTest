﻿using BankManagementSystem.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace BankManagementSystem.Model
{
    public class ValidationCls
    {
        //public LoginVM LoginVM;
        //public Regex regex;// = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
        //public ValidationCls() { 
        //LoginVM= new LoginVM();
        //}

        //public bool ValidateLogin(string username, string password)
        //{
        //    if (username.Length >= 20 || username.Length < 8)
        //    {
        //        LoginVM.LoginUN="User Name should not be greater than 20 character or less than 8 character";
        //        return false;
        //    }
        //    if (password.Length >= 20 || password.Length < 8)
        //    {
        //        LoginVM.LoginPWD = "Password should not be greater than 20 character or less than 8 character";
        //        return false;
        //    }
        //    else
        //        return true;
            
        //}

        //public bool ValidateUser(User user)
        //{
        //    //if (Name.Length >= 51)
        //    //{
        //    //    ShowError("Name should be contains 50 charcter");
        //    //    return false;
        //    //}
        //    //if (Username.Length >= 51 || Username.Length < 8)
        //    //{
        //    //    ShowError("User Name should not be greater than 20 character or less than 8 character");
        //    //    return false;
        //    //}
        //    //if (regex.IsMatch(Email))
        //    //{
        //    //    Match match = regex.Match(email);
        //    //    if (!match.Success)
        //    //    {
        //    //        return false;
        //    //    }
        //    //    else
        //    //        return false;
        //    //}
        //    //else
        //        return true;
        //}
    }
}
