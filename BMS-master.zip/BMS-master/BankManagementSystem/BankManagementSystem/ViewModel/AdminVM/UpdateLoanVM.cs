﻿using BankManagementSystem.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankManagementSystem.ViewModel.AdminVM
{
    public class UpdateLoanVM:BaseVM
    {
        public UpdateLoanVM()
        {
                
        }

        private Loan loan;

        public Loan Loan
        {
            get { return loan; }
            set
            {
                loan = value;
                OnPropertyChanged(nameof(Loan));
            }
        }
        private string loanType;

        public string LoanType
        {
            get { return loanType; }
            set
            {
                loanType = value;
                OnPropertyChanged(nameof(LoanType));
            }
        }

        private double loanAmount;
        public double LoanAmount
        {
            get { return loanAmount; }
            set
            {
                loanAmount = value;
                OnPropertyChanged(nameof(LoanAmount));
            }
        }

        private DateTime date;
        public DateTime Date
        {
            get { return date; }
            set
            {
                date = value;
                OnPropertyChanged(nameof(Date));
            }
        }

        private int rateOfInterest;
        public int RateOfInterest
        {
            get { return rateOfInterest; }
            set
            {
                rateOfInterest = value;
                OnPropertyChanged(nameof(RateOfInterest));
            }
        }

        private int loanDuration;
        public int LoanDuration
        {
            get { return loanDuration; }
            set
            {
                loanDuration = value;
                OnPropertyChanged(nameof(LoanDuration));
            }
        }
        public void SetGrid(Loan loan)
        {

        }
    }
}
