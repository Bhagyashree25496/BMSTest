﻿using BankManagementSystem.Model;
using BankManagementSystem.View;
using BankManagementSystem.ViewModel.Command;
using BankManagementSystem.ViewModel.Helper;
using CS.ViewModel.Handler;
using Microsoft.VisualStudio.PlatformUI;
using Prism.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace BankManagementSystem.ViewModel.AdminVM
{
    public class AdminLoanVM:BaseVM
    {
        public ILoginHandler loginHandler;
        public EmailOn_Update EmailOn_Update;
        public event EventHandler Authenticated;

        public ICommand UpdateLoanCommand { get; set; }
        public ICommand SaveLoanCommand { get; set; }

        private List<Loan> userLoan;

        public List<Loan> UserLoan
        {
            get { return userLoan; }
            set
            {
                userLoan = value;
                OnPropertyChanged(nameof(UserLoan));
            }
        }


        public AdminLoanVM()
        {
            UpdateLoanCommand = new UpdateLoanCommand(this);
            SaveLoanCommand= new SaveLoanCommand(this);
            loginHandler = new LoginHandler();
            this.GetLoan();
            this.ShowViewLoan();
        }

        
        public async void GetLoan()
        {
            UserLoan = await loginHandler.GetLoan();
            
        }
        
        private Loan loan;
        public Loan Loan
        {
            get { return loan; }
            set
            {
                loan = value;
                OnPropertyChanged(nameof(Loan));
            }
        }

        private int loanId;

        public int LoanId
        {
            get { return loanId; }
            set
            {
                loanId = value;
 
                OnPropertyChanged(nameof(LoanId));
            }
        }

        private int userId;

        public int UserId
        {
            get { return userId; }
            set
            {
                userId = value;

                OnPropertyChanged(nameof(UserId));
            }
        }

        private string loanType;

        public string LoanType
        {
            get { return loanType; }
            set
            {
                loanType = value;
                OnPropertyChanged(nameof(LoanType));
            }
        }

        private double loanAmount;
        public double LoanAmount
        {
            get { return loanAmount; }
            set
            {
                loanAmount = value;
                OnPropertyChanged("LoanAmount");
            }
        }

        private DateTime date=DateTime.Now;
        public DateTime Date
        {
            get { return date; }
            set
            {
                date = value;
                OnPropertyChanged("Date");
            }
        }

        private int rateOfInterest;
        public int RateOfInterest
        {
            get { return rateOfInterest; }
            set
            {
                rateOfInterest = value;
                OnPropertyChanged(nameof(RateOfInterest));
            }
        }

        private int loanDuration;
        public int LoanDuration
        {
            get { return loanDuration; }
            set
            {
                loanDuration = value;
                OnPropertyChanged(nameof(LoanDuration));
            }
        }

        private string comments;

        public string Comments
        {
            get { return comments; }
            set { 
                comments = value;
                Loan = new Loan()
                {
                    LoanId = this.LoanId,
                    UserId = this.UserId,
                    LoanType = this.LoanType,
                    LoanAmount = this.LoanAmount,
                    Date = this.Date,
                    RateOfInterest = this.RateOfInterest,
                    LoanDuration = this.LoanDuration,
                    Comments= comments,
                    Status= this.Status

                };
                OnPropertyChanged(nameof(Comments));
                }
        }
        private string status;

        public string Status
        {
            get { return status; }
            set
            {
                status = value;
                Loan = new Loan()
                {
                    LoanId= this.LoanId,
                    UserId= this.UserId,
                    LoanType = this.LoanType,
                    LoanAmount = this.LoanAmount,
                    Date = this.Date,
                    RateOfInterest = this.RateOfInterest,
                    LoanDuration = this.LoanDuration,
                    Comments = this.Comments,
                    Status = status

                };
                OnPropertyChanged(nameof(Status));
            }
        }

        private Visibility viewLoanVis;
        public Visibility ViewLoanVis
        {
            get { return viewLoanVis; }
            set
            {
                viewLoanVis = value;
                OnPropertyChanged("ViewLoanVis");
            }
        }

        private Visibility updateLoanVis;
        public Visibility UpdateLoanVis
        {
            get { return updateLoanVis; }
            set
            {
                updateLoanVis = value;
                OnPropertyChanged("UpdateLoanVis");
            }
        }

        public void ShowUpdateLoan(Loan obj)
        {
            Loan =obj;
            UserId= obj.UserId;
            LoanId = Loan.LoanId;
            LoanType=obj.LoanType;
            LoanAmount=obj.LoanAmount;
            Date=obj.Date;
            RateOfInterest=obj.RateOfInterest;
            LoanDuration=obj.LoanDuration;
            Comments = "";
            UpdateLoanVis = Visibility.Visible;
            ViewLoanVis = Visibility.Collapsed;
        }
        public void ShowViewLoan()
        {
            ViewLoanVis = Visibility.Visible;
            UpdateLoanVis= Visibility.Collapsed;
        }

        public async void UpdateLoan(Loan loan)
        {
           
                var test = await loginHandler.UpdateLoan(loan);
                if (test != null)
                {
                    UserLoan = test;
                    ShowViewLoan();
                    var user = await loginHandler.GetUser(loan.UserId);
                    EmailOn_Update=new EmailOn_Update(user,loan);
                }
            

        }
    }
}
