﻿using BankManagementSystem.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace BankManagementSystem.ViewModel.Command
{
    public class LogoutCommand : ICommand
    {
        public AdminDashVM AdminDashVM;
        public UserDashVM UserDashVM;

        public LogoutCommand(AdminDashVM adminDashVM)
        {
            AdminDashVM = adminDashVM;
            
        }
        public LogoutCommand(UserDashVM UserDashVM)
        {
            UserDashVM = UserDashVM;

        }

        public event EventHandler? CanExecuteChanged;

        public bool CanExecute(object? parameter)
        {
            return true;
        }

        public void Execute(object? parameter)
        {
            if(parameter.ToString()== "AdminLogout")
            {
                AdminDashVM.Logout(parameter as User);
            }
            else if(parameter.ToString() == "UserLogout")
            {
                UserDashVM.Logout(parameter as User);
            }
        }
    }
}
