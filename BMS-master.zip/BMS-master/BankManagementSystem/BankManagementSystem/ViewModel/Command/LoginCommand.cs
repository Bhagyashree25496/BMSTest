﻿using BankManagementSystem.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Input;

namespace BankManagementSystem.ViewModel.Command
{
    public class LoginCommand : ICommand
    {

          
        public LoginVM ViewModel { get; set; }
        public UserVM userVM { get; set; }
        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        public LoginCommand(LoginVM vm)
        {
            ViewModel = vm;
        }

        public bool CanExecute(object parameter)
        {
            User user = parameter as User;

            if (user == null)
                return false;
            if (string.IsNullOrEmpty(user.UserName))
                return false;
 
            if (string.IsNullOrEmpty(user.Password) )
                return false;
            return true;
        }

        public void Execute(object parameter)
        {
            User user = parameter as User;
            ViewModel.Login(user);
            
        }
    }
}
