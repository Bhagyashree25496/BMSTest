﻿using BankManagementSystem.Model;
using BankManagementSystem.ViewModel.AdminVM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace BankManagementSystem.ViewModel.Command
{
    public class UpdateLoanCommand : ICommand
    {
        public AdminLoanVM AdminLoanVM;
        
        public UpdateLoanCommand(AdminLoanVM adminLoanVM)
        {
            AdminLoanVM = adminLoanVM;
        }
        
        public event EventHandler? CanExecuteChanged;

        public bool CanExecute(object? parameter)
        {
            return true;
        }

        public void Execute(object? parameter)
        {
            AdminLoanVM.ShowUpdateLoan(parameter as Loan);
        }
    }
}
