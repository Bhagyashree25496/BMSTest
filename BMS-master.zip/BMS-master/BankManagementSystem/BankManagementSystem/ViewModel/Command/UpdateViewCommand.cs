﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace BankManagementSystem.ViewModel.Command
{
    public class UpdateViewCommand : ICommand
    {
        private UserDashVM viewModel;
        public LoginVM loginviewModel;
        public UpdateViewCommand(UserDashVM userDetailsVM)
        {
            viewModel = userDetailsVM;
        }

        public UpdateViewCommand(LoginVM LoginviewModel)
        {
            loginviewModel = LoginviewModel;
        }

        public event EventHandler? CanExecuteChanged;

        public bool CanExecute(object? parameter)
        {
            return true;
        }

        public void Execute(object? parameter)
        {
            if(parameter.ToString()== "UserDetails")
            {
                viewModel.SelectedVM = new UserDetailsVM();
            }
            else if (parameter.ToString() == "LoanDetails")
            {
                viewModel.SelectedVM = new UserLoanVM();
            }
            else if(parameter.ToString() == "ApplyLoan")
            {
                viewModel.SelectedVM = new AddLoanVM();
            }
            else if (parameter.ToString() == "UserLogout")
            {
                viewModel.SelectedVM = new LoginVM();
            }

        }
    }
}
