﻿using BankManagementSystem.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Input;

namespace BankManagementSystem.ViewModel.Command
{
    public class RegisterCommand : ICommand
    {
         
        public LoginVM ViewModel { get; set; }
        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        public RegisterCommand(LoginVM vm)
        {
            ViewModel = vm;
        }

        
        public bool CanExecute(object parameter)
            {
            User user = parameter as User;

            if (user == null)
                return false;
            if (string.IsNullOrEmpty(user.UserName)|| user.UserName.Length < 8|| user.UserName.Length > 20)
                return false;
            if (string.IsNullOrEmpty(user.Password)|| user.Password.Length < 8 || user.Password.Length > 20)
                return false;
            if (string.IsNullOrEmpty(user.Email))
                return false;
            if (string.IsNullOrEmpty(user.State))
                return false;
            if (string.IsNullOrEmpty(user.County))
                return false;
            if (string.IsNullOrEmpty(user.ContactNo))
                return false;
            if (string.IsNullOrEmpty(user.PAN))
                return false;
            if (user.DOB>DateTime.Now)
                return false;

            return true;
        }

        public void Execute(object parameter)
        {
            ViewModel.Register(parameter as User);
        }
    }
}
