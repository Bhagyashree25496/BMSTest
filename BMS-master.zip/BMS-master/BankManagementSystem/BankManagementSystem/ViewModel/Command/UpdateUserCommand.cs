﻿using BankManagementSystem.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace BankManagementSystem.ViewModel.Command
{
    public class UpdateUserCommand : ICommand
    {
        public UserDetailsVM UserDetailsVM;

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        public UpdateUserCommand(UserDetailsVM userDetailsVM)
        {
            UserDetailsVM = userDetailsVM;
        }

        
        public bool CanExecute(object? parameter)
        {
            return true;
        }

        public void Execute(object? parameter)
        {
            UserDetailsVM.UpdateUser(parameter as User);
            MessageBox.Show("Updated successfully");
        }
    }
}
