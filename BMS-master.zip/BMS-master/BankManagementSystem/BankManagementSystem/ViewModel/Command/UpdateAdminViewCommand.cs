﻿using BankManagementSystem.ViewModel.AdminVM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace BankManagementSystem.ViewModel.Command
{
    public class UpdateAdminViewCommand : ICommand
    {
        private AdminDashVM viewModel;

        public UpdateAdminViewCommand(AdminDashVM viewModel)
        {
            this.viewModel = viewModel;
        }

        public event EventHandler? CanExecuteChanged;

        public bool CanExecute(object? parameter)
        {
            return true;
        }

        public void Execute(object? parameter)
        {
            if (parameter.ToString() == "AdminDetails")
            {
                viewModel.SelectedVM = new AdminUserVM();
            }
            else if (parameter.ToString() == "AdminAllLoanDetails")
            {
                viewModel.SelectedVM = new AdminLoanVM();
            }
            
        }
    }
}
