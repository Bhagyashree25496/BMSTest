﻿using BankManagementSystem.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace BankManagementSystem.ViewModel.Command
{
    public class AddLoanCommand : ICommand
    {
        private AddLoanVM addLoanVM;

        public AddLoanCommand(AddLoanVM addLoanVM)
        {
            this.addLoanVM = addLoanVM;
        }

        public event EventHandler? CanExecuteChanged;

        public bool CanExecute(object? parameter)
        {
            return true;
        }

        public void Execute(object? parameter)
        {
            addLoanVM.AddNewLoan(parameter as Loan);
            MessageBox.Show("Applied successfully");
        }
    }
}
