﻿using BankManagementSystem.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace BankManagementSystem.ViewModel.Helper
{
    public class EmailOn_Update
    {
        string Sender = "bhagu201225@gmail.com";
        string Password = "qhezuylkkcdcyipm";
        public EmailOn_Update(User user,Loan loan)
        {
            this.SendEmail(user,loan);
        }

        public void SendEmail(User user,Loan loan)
        {
            string Receiver = user.Email;
            MailMessage Message = new MailMessage();
            Message.From = new MailAddress(Sender);
            Message.Subject = "Loan Application Status Updates for "+user.Name;
            Message.Body = "<html>" +
                "<body>" +
                "<p>Dear "+user.Name+"</p>" +
                "<p>Please find updates on your applied loan as below:</p>" +
                "<p>User ID:"+user.UserId+"</p>" +
                "<p>Loan ID:"+loan.LoanId+"</p>" +
                "<p>Loan Type:"+loan.LoanType+"</p>" +
                "<p>Updated Status:"+loan.Status+"<p>" +
                "<p>Comment:"+loan.Comments+"</p>" +
                "<p>Please login to portal for further details</p>" +
                "<p>Thanks & regards,<br>" +
                "CB Bank Pvt Ltd</p></body></html>";
            Message.To.Add(new MailAddress(Receiver));
            Message.IsBodyHtml = true;

            var smtpClient = new SmtpClient("smtp.gmail.com")
            {
                Port = 587,
                Credentials = new NetworkCredential(Sender, Password),
                EnableSsl = true
            };

            smtpClient.Send(Message);
        }
    }
}
