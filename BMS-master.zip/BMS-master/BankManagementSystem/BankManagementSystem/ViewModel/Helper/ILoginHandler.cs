﻿using BankManagementSystem.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankManagementSystem.ViewModel.Helper
{
    public interface ILoginHandler
    {
        Task<User> AuthUser(User user);

        Task<User> AddUser(User user);

        Task<User> GetUser(int userid);

        Task<User> UpdateUser(User user);

        Task<List<Loan>> GetLoan();
        Task<Loan> GetLoanByID(int userid, int loanid);

        Task<List<Loan>> GetLoanByUserID(int userid);

        Task<Loan> AddLoan(Loan loan);

        Task<List<Loan>> UpdateLoan(Loan loan);


    }
}
