﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using BankManagementSystem.Model;
using System.Text.Json;
using System.Configuration;
using Newtonsoft.Json.Linq;
using System.Net.Http.Json;
using BankManagementSystem.ViewModel;
using BankManagementSystem.Error;
using BankManagementSystem.ViewModel.Helper;

namespace CS.ViewModel.Handler
{
    public class LoginHandler : ILoginHandler
    {

        ErroLog erroLog = new ErroLog();

        public LoginHandler()
        {

        }
        public async Task<User> GetUser( int userid)
        {
            User responseObj = new User();

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:7105/");
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = new HttpResponseMessage();
                response = await client.GetAsync("Auth/"+userid).ConfigureAwait(false);

                // Verification  
                if (response.IsSuccessStatusCode)
                {
                    string result = response.Content.ReadAsStringAsync().Result;
                    responseObj = JsonConvert.DeserializeObject<User>(result);
                }
            }

            return responseObj;
        }

        public async Task<User> AuthUser(User user)
        {
            try
            {
                User users = new User();

                using (HttpClient client = new HttpClient())
                {
                    var response = await client.GetAsync("https://localhost:7105/Auth/" + user.UserName + "/" + user.Password);
                    if (response.ReasonPhrase == "No Content")
                    {
                        return null;
                    }
                    string json = await response.Content.ReadAsStringAsync();

                    users = JsonConvert.DeserializeObject<User>(json);
                }

                return users;
            }
            catch(Exception ex)
            {
                ErroLog.SendErrorToText(ex, "\\ViewModel\\Helper\\AuthUser");
                return null;
            }
        }

        public async Task<User> AddUser(User user)
        {
            try
            {
                User Respuser = new User();
            
            HttpResponseMessage rsp ;
            
            using (HttpClient client = new HttpClient())
            {
                var str=JsonConvert.SerializeObject(user);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                rsp = await client.PostAsJsonAsync("https://localhost:7105/Auth/", user);
                string jsons = await rsp.Content.ReadAsStringAsync();

                Respuser = JsonConvert.DeserializeObject<User>(jsons);
            }

            return Respuser;
            }
            catch (Exception ex)
            {
                ErroLog.SendErrorToText(ex, "\\ViewModel\\Helper\\AuthUser");
                return null;
            }
        }

        public async Task<User> UpdateUser(User user)
        {
            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                
                var rsp = await client.PutAsJsonAsync("https://localhost:7105/Auth/", user);
                
                string strn = await rsp.Content.ReadAsStringAsync();

                user = JsonConvert.DeserializeObject<User>(strn);
            }

            return user;
        }

        public async Task<List<Loan>> GetLoan()
        {
            List<Loan> respObj = new List<Loan>();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:7105/");
                
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                
                HttpResponseMessage response = new HttpResponseMessage();
                
                response = await client.GetAsync("Loan/").ConfigureAwait(false);
                

                if (response.IsSuccessStatusCode)
                {
                    string result = response.Content.ReadAsStringAsync().Result;
                    respObj = JsonConvert.DeserializeObject<List<Loan>>(result);
                }
            }

            return respObj;
        }

        public async Task<Loan> GetLoanByID(int userid,int loanid)
        {
            Loan responseObj = new Loan();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:7105/");

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage response = new HttpResponseMessage();

                response = await client.GetAsync("Loan/" + userid+"/"+loanid).ConfigureAwait(false);

                if (response.IsSuccessStatusCode)
                {
                    string result = response.Content.ReadAsStringAsync().Result;
                    responseObj = JsonConvert.DeserializeObject<Loan>(result);
                }
            }
            return responseObj;

        }

        public async Task<List<Loan>> GetLoanByUserID(int userid)
        {
            List<Loan> responseObj = new List<Loan>();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:7105/");

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage response = new HttpResponseMessage();

                response = await client.GetAsync("Loan/" + userid).ConfigureAwait(false);

                if (response.IsSuccessStatusCode)
                {
                    string result = response.Content.ReadAsStringAsync().Result;
                    responseObj = JsonConvert.DeserializeObject<List<Loan>>(result);
                }
            }
            return responseObj;
        }
        public async Task<Loan> AddLoan(Loan loan)
        {
            Loan respObj= new Loan();
            loan.UserId = UserDate.UserID;
            loan.Comments = "";
            loan.Status = "Active";
            HttpResponseMessage rsp;
            
            using (HttpClient client = new HttpClient())
            {
                var str = JsonConvert.SerializeObject(loan);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                
                rsp = await client.PostAsJsonAsync("https://localhost:7105/Loan/", loan);
                
            }

            return loan;
        }

        public async Task<List<Loan>> UpdateLoan(Loan loan)
        {
            List<Loan> respObj = new List<Loan>();

            HttpResponseMessage rsp;

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                rsp = await client.PutAsJsonAsync("https://localhost:7105/Loan/", loan);

                string json = await rsp.Content.ReadAsStringAsync();

                respObj = JsonConvert.DeserializeObject<List<Loan>>(json);
            }

            return respObj;
        }

    }
}
