﻿using BankManagementSystem.Model;
using BankManagementSystem.View;
using BankManagementSystem.ViewModel.Command;
using BankManagementSystem.ViewModel.Helper;
using CS.ViewModel.Handler;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace BankManagementSystem.ViewModel
{
    public class LoginVM : BaseVM
    {
        private bool isShowingRegister = false;
        private bool _isViewVisible = true;
        

        public bool IsViewVisible
        {
            get { return _isViewVisible; }
            set
            {
                _isViewVisible = value;
                OnPropertyChanged(nameof(IsViewVisible));
            }
        }

        private User user;
        public User User
        {
            get { return user; }
            set
            {
                user = value;
                OnPropertyChanged("User");
            }
        }
        
        private string username;
        public string Username
        {
            get { return username; }
            set
            {
                username = value;
                User = new User
                {
                    UserName = username,
                    Password = this.Password,
                    Name = this.Name,
                    Address=this.Address,
                    State= this.State,
                    County=this.County,
                    PAN=this.PAN,
                    Email=this.Email,
                    DOB=this.DOB,
                    AccountType=this.AccountType,
                    ContactNo=this.ContactNo

                };
                OnPropertyChanged("Username");
            }
        }

        private string password;
        public string Password
        {
            get { return password; }
            set
            {
                password = value;
                User = new User
                {
                    UserName = this.Username,
                    Password = password,
                    Name = this.Name,
                    Address = this.Address,
                    State = this.State,
                    County = this.County,
                    PAN = this.PAN,
                    Email = this.Email,
                    DOB = this.DOB,
                    AccountType = this.AccountType,
                    ContactNo = this.ContactNo
                };
                OnPropertyChanged("Password");
            }
        }

        private string name;
        public string Name
        {
            get { return name; }
            set
            {
                name = value;
                User = new User
                {
                    UserName = this.Username,
                    Password = this.Password,
                    Name = name,
                    Address = this.Address,
                    State = this.State,
                    County = this.County,
                    PAN = this.PAN,
                    Email = this.Email,
                    DOB = this.DOB,
                    AccountType = this.AccountType,
                    ContactNo = this.ContactNo
                };
                OnPropertyChanged("Name");
            }
        }

        private string address;
        public string Address
        {
            get { return address; }
            set
            {
                address = value;
                User = new User
                {
                    UserName = this.Username,
                    Password = this.Password,
                    Name = this.Name,
                    Address = address,
                    State = this.State,
                    County = this.County,
                    PAN = this.PAN,
                    Email = this.Email,
                    DOB = this.DOB,
                    AccountType = this.AccountType,
                    ContactNo = this.ContactNo
                };
                OnPropertyChanged("Address");
            }
        }

        private string state;
        public string State
        {
            get { return state; }
            set
            {
                state = value;
                User = new User
                {
                    UserName = this.Username,
                    Password = this.Password,
                    Name = this.Name,
                    Address = this.Address,
                    State = state,
                    County = this.County,
                    PAN = this.PAN,
                    Email = this.Email,
                    DOB = this.DOB,
                    AccountType = this.AccountType,
                    ContactNo = this.ContactNo
                };
                OnPropertyChanged("State");
            }
        }

        private string county;
        public string County
        {
            get { return county; }
            set
            {
                county = value;
                User = new User
                {
                    UserName = this.Username,
                    Password = this.Password,
                    Name = this.Name,
                    Address = this.Address,
                    State = this.State,
                    County = county,
                    PAN = this.PAN,
                    Email = this.Email,
                    DOB = this.DOB,
                    AccountType = this.AccountType,
                    ContactNo = this.ContactNo
                };
                OnPropertyChanged("County");
            }
        }


        private string pan;
        public string PAN
        {
            get { return pan; }
            set
            {
                pan = value;
                User = new User
                {
                    UserName = this.Username,
                    Password = this.Password,
                    Name = this.Name,
                    Address = this.Address,
                    State = this.State,
                    County = this.County,
                    PAN = pan,
                    Email = this.Email,
                    DOB = this.DOB,
                    AccountType = this.AccountType,
                    ContactNo = this.ContactNo
                };
                OnPropertyChanged("Pan");
            }
        }

        private string email;
        public string Email
        {
            get { return email; }
            set
            {
                email = value;
                User = new User
                {
                    UserName = this.Username,
                    Password = this.Password,
                    Name = this.Name,
                    Address = this.Address,
                    State = this.State,
                    County = this.County,
                    PAN = this.PAN,
                    Email = email,
                    DOB = this.DOB,
                    AccountType = this.AccountType,
                    ContactNo = this.ContactNo
                };
                OnPropertyChanged("Email");
            }
        }


        private DateTime dob = DateTime.Now.AddYears(-18);
        public DateTime DOB
        {
            get { return dob; }
            set
            {
                dob = value;
                User = new User
                {
                    UserName = this.Username,
                    Password = this.Password,
                    Name = this.Name,
                    Address = this.Address,
                    State = this.State,
                    County = this.County,
                    PAN = this.PAN,
                    Email = this.Email,
                    DOB = dob,
                    AccountType = this.AccountType,
                    ContactNo = this.ContactNo
                };
                OnPropertyChanged("DOB");
            }
        }

        private string accountType;
        public string AccountType
        {
            get { return accountType; }
            set
            {
                accountType = value;
                User = new User
                {
                    UserName = this.Username,
                    Password = this.Password,
                    Name = this.Name,
                    Address = this.Address,
                    State = this.State,
                    County = this.County,
                    PAN = this.pan,
                    Email = this.Email,
                    DOB = this.DOB,
                    AccountType = accountType,
                    ContactNo = this.ContactNo
                };
                OnPropertyChanged("AccountType");
            }
        }

        private string usrErr;
        public string UsrErr
        {
            get { return usrErr; }
            set
            {
                usrErr = value;
                OnPropertyChanged("UsrErr");
            }
        }


        private string contactNo;
        public string ContactNo
        {
            get { return contactNo; }
            set
            {
                contactNo = value;
                User = new User
                {
                    UserName = this.Username,
                    Password = this.Password,
                    Name = this.Name,
                    Address = this.Address,
                    State = this.State,
                    County = this.County,
                    PAN = this.pan,
                    Email = this.Email,
                    DOB = this.DOB,
                    AccountType = this.AccountType,
                    ContactNo = contactNo
                };
                OnPropertyChanged("ContactNo");
            }
        }


        private Visibility loginVis;
        public Visibility LoginVis
        {
            get { return loginVis; }
            set
            {
                loginVis = value;
                OnPropertyChanged("LoginVis");
            }
        }

        private Visibility registerVis;
        public Visibility RegisterVis
        {
            get { return registerVis; }
            set
            {
                registerVis = value;
                OnPropertyChanged("RegisterVis");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public event EventHandler Authenticated;

        public RegisterCommand RegisterCommand { get; set; }
        public LoginCommand LoginCommand { get; set; }
        public ShowRegisterCommand ShowRegisterCommand { get; set; }

        public ILoginHandler loginHandler;
        
        public ICommand UpdateUserCommand { get; set; }

        public LoginVM()
        {
            LoginVis = Visibility.Visible;
            RegisterVis = Visibility.Collapsed;
            RegisterCommand = new RegisterCommand(this);
            LoginCommand = new LoginCommand(this);
            ShowRegisterCommand = new ShowRegisterCommand(this);
            loginHandler= new LoginHandler();
            User = new User();
        }
        

        public void SwitchViews()
        {
            isShowingRegister = !isShowingRegister;

            if (isShowingRegister)
            {
                
                RegisterVis = Visibility.Visible;
                LoginVis = Visibility.Collapsed;
                Username = string.Empty;
                Password = string.Empty;
                
            }
            else
            {
                RegisterVis = Visibility.Collapsed;
                LoginVis = Visibility.Visible;
                Username = string.Empty;
                Password = string.Empty;
               
            }
            
        }

        public void ShowError(string error)
        {
                UsrErr = error;
            
        }
        public User test;
        public async void Login(User user)
        {
           test = await loginHandler.AuthUser(user);

                if (test == null)
                {
                    this.ShowError("Wrong username or password");
                }
                else
                {
                    UserDate.UserID = test.UserId;
                    UserDate.UserName = test.UserName;
                    UserDate.Password = test.Password;
                    UserDate.Role = test.Role;
                    Authenticated?.Invoke(this, new EventArgs());
                }
        
        }

        public async void Register(User user)
        {
            test = await loginHandler.AddUser(user);
            if(test==null)
            {
                MessageBox.Show("Given username is already being used, try with another username");
            }
            else
            {
                RegisterVis = Visibility.Collapsed;
                LoginVis = Visibility.Visible;
            }
        }

    }
}
