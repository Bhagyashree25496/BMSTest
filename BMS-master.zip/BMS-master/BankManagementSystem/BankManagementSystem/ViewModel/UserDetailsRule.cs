﻿using BankManagementSystem.Model;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Metrics;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Xml.Linq;

namespace BankManagementSystem.ViewModel
{
    public class UserDetailsRule : ValidationRule
    {
        Regex regexusrName = new Regex("^[a-zA-Z0-9 ]*$");
        Regex regexName = new Regex("^[a-zA-Z ]*$");
        Regex regexPAN = new Regex("^[a-zA-Z0-9]*$");
        Regex regemEmail = new Regex("[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?");
        Regex regexPwd1 = new Regex("(?=.*[a-z])");
        Regex regexPwd2 = new Regex("(?=.*[A-Z])");
        Regex regexPwd3 = new Regex("(?=.*\\d)");
        Regex regexPwd4 = new Regex("(?=.*\\W)");
        Regex regexNum = new Regex("^[0-9]*$");
        
        public int MinimumChar { get; set; }
        public string name { get; set; }
        public string result { get; set; }

        public DateTime valdate;
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            string charString = value as string;
            if (name=="DOB"||name=="Date")
                valdate = Convert.ToDateTime(value);
            
            
            switch(name)
            {
                case "Name":

                    if (string.IsNullOrEmpty(charString))
                        result = "Cannot be empty";
                    else if (!regexName.IsMatch(charString))
                        result = "Can only have alphabets";
                    else if (charString.Length > 50)
                        result = "Must be max of 50 characters.";
                    else
                        result = null;
                    break;

                case "Username":
                    if (string.IsNullOrEmpty(charString))
                        result = "Cannot be empty";
                    else if (charString.Length < 8 || charString.Length > 20)
                        result = "Must be between 8 to 20 characters.";
                    else if (!regexusrName.IsMatch(charString))
                        result = "Cannot have special characters";
                    else
                        result = null;
                    break;

                case "Password":
                    if (string.IsNullOrEmpty(charString))
                        result = "Cannot be empty";
                    else if (charString.Length < 8 || charString.Length > 20)
                        result = "Must be between 8 to 20 characters.";
                    else if (!regexPwd2.IsMatch(charString))
                        result = "Must have atleast 1 capital letter";
                    else if (!regexPwd1.IsMatch(charString))
                        result = "Must have atleast 1 small letter";
                    else if (!regexPwd3.IsMatch(charString))
                        result = "Must have atleast 1 number";
                    else if (!regexPwd4.IsMatch(charString))
                        result = "Must have atleast 1 special character";
                    else
                        result = null;
                    break;

                case "Address":
                    if (string.IsNullOrEmpty(charString))
                        result = "Cannot be empty";
                    else if (charString.Length > 200)
                        result = "Must be max of 200 characters";
                    else
                        result = null;
                    break;

                case "State":
                    if (string.IsNullOrEmpty(charString))
                        result = "Cannot be empty";
                    else if (charString.Length > 50)
                        result = "Must be max of 50 characters.";
                    else
                        result = null;
                    break;

                case "County":
                    if (string.IsNullOrEmpty(charString))
                        result = "Cannot be empty";
                    else if (charString.Length > 100)
                        result = "Must be max of 100 characters.";
                    else
                        result = null;
                    break;

                case "Email":
                    if (string.IsNullOrEmpty(charString))
                        result = "Cannot be empty";
                    else if (!regemEmail.IsMatch(charString))
                        result = "Must be in standard email format";
                    else
                        result = null;
                    break;

                case "PAN":
                    if (string.IsNullOrEmpty(charString))
                        result = "Cannot be empty";
                    else if (!regexPAN.IsMatch(charString))
                        result="cannot have special character";
                    else if (charString.Length != 10)
                        result = "Must be of 10 characters";
                    else
                        result = null;
                    break;

                case "ContactNo":
                    if (string.IsNullOrEmpty(charString))
                        result = "Cannot be empty";
                    else if (!regexNum.IsMatch(charString))
                        result="must contain numbers";
                    else if (charString.Length != 10)
                        result = "Must be of 10 numbers";
                    else
                        result = null;
                    break;
               
                case "DOB":
                    if (valdate > DateTime.Now.AddYears(-18))
                        result = "User should be above 18 years of age";
                    else if (Convert.ToDateTime(charString) > DateTime.Now)
                        result = "Future date is not allowed";
                    else
                        result = null;
                    break;
                
                case "LoanAmount":
                    if (string.IsNullOrEmpty(charString))
                        result = "Cannot be empty";
                    else if(Convert.ToInt32(charString) < 1)
                        result = "LoanAmount cannot be 0";
                    else
                        result = null;
                    break;
                
                case "Date":
                    if (valdate > DateTime.Now)
                        result = "Cannot be future date";
                    else
                        result = null;
                    break;
                
                case "RateOfInterest":
                    if (string.IsNullOrEmpty(charString))
                        result = "Cannot be empty";
                    else if (Convert.ToInt32(charString) > 100 )
                        result = "cannot be greater than 100";
                    else if(Convert.ToInt32(charString) < 1)
                        result = "cannot be less than 1";
                    else
                        result = null;
                    break;
                
                case "LoanDuration":
                    if (string.IsNullOrEmpty(charString))
                        result = "Cannot be empty";
                    else if (Convert.ToInt32(charString) <= 0)
                        result = "cannot be 0";
                    else if (Convert.ToInt32(charString) > 100)
                        result = "cannot be greater than 100";
                    else
                        result = null;
                    break;
            }
            if (result!=null)
            {
                return new ValidationResult(false, result);
            }
            return new ValidationResult(true, null);

        }
    }
}
