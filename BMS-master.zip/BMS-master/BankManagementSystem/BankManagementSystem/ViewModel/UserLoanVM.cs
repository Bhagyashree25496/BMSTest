﻿using BankManagementSystem.Model;
using BankManagementSystem.ViewModel.Helper;
using CS.ViewModel.Handler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankManagementSystem.ViewModel
{
    public class UserLoanVM : BaseVM
    {
        public ILoginHandler loginHandler;
        private List<Loan> userLoan;

        public List<Loan> UserLoan
        {
            get { return userLoan; }
            set { userLoan = value; 
                    OnPropertyChanged(nameof(UserLoan));
                 }
        }

        

        public UserLoanVM()
        {
            loginHandler = new LoginHandler();
            this.GetLoan();
        }

        public async void GetLoan()
        {
            UserLoan=await loginHandler.GetLoanByUserID(UserDate.UserID);
        }
    }
}
