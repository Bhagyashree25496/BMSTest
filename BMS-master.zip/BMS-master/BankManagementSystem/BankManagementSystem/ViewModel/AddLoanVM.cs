﻿using BankManagementSystem.Model;
using BankManagementSystem.View;
using BankManagementSystem.ViewModel.Command;
using BankManagementSystem.ViewModel.Helper;
using CS.ViewModel.Handler;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Net;
using System.Security.Cryptography.Xml;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Xml.Linq;

namespace BankManagementSystem.ViewModel
{
    public class AddLoanVM:BaseVM
    {
        public ICommand AddLoanCommand { get; set; }
        public ILoginHandler loginHandler;
        public UserDashVM UserDashVM;
        public BaseVM selectedVM;

        public Loan resp;

        private string loanType;

        public string LoanType
        {
            get { return loanType; }
            set { 
                loanType = value;
                Loan = new Loan()
                {
                    LoanType = loanType,
                    LoanAmount = this.LoanAmount,
                    Date = this.Date,
                    RateOfInterest = this.RateOfInterest,
                    LoanDuration = this.LoanDuration

                };
                OnPropertyChanged(nameof(LoanType));
            }
        }

        private double loanAmount;
        public double LoanAmount
        {
            get { return loanAmount; }
            set { loanAmount = value;
                Loan = new Loan()
                {
                    LoanType = this.LoanType,
                    LoanAmount = loanAmount,
                    Date = this.Date,
                    RateOfInterest = this.RateOfInterest,
                    LoanDuration = this.LoanDuration

                };
                OnPropertyChanged(nameof(LoanAmount));
            }
        }

        private DateTime date = DateTime.Now;
        public DateTime Date
        {
            get { return date; }
            set { date = value;
                Loan = new Loan()
                {
                    LoanType = this.LoanType,
                    LoanAmount = this.LoanAmount,
                    Date = date,
                    RateOfInterest = this.RateOfInterest,
                    LoanDuration = this.LoanDuration

                };
                OnPropertyChanged(nameof(Date));
            }
        }

        private int rateOfInterest;
        public int RateOfInterest
        {
            get { return rateOfInterest; }
            set { 
                rateOfInterest = value;
                Loan = new Loan()
                {
                    LoanType = this.LoanType,
                    LoanAmount = this.LoanAmount,
                    Date = this.Date,
                    RateOfInterest = rateOfInterest,
                    LoanDuration = this.LoanDuration

                };
                OnPropertyChanged(nameof(RateOfInterest));
            }
        }

        private int loanDuration;
        public int LoanDuration
        {
            get { return loanDuration; }
            set { 
                loanDuration = value;
                Loan = new Loan()
                {
                    LoanType = this.loanType,
                    LoanAmount = this.loanAmount,
                    Date = this.date,
                    RateOfInterest = this.rateOfInterest,
                    LoanDuration = loanDuration

                };
                OnPropertyChanged(nameof(LoanDuration));
            }
        }

        public AddLoanVM()
        {
            Date=DateTime.Now;
            AddLoanCommand = new AddLoanCommand(this);
            loginHandler = new LoginHandler();
            UserDashVM=new UserDashVM();
            selectedVM = new BaseVM(); 
                
        }

        private Loan loan;

        public Loan Loan
        {
            get { return loan; }
            set { loan = value;
                OnPropertyChanged(nameof(Loan));
            }
        }

        
        public async void AddNewLoan(Loan loan)
        {
            resp = await loginHandler.AddLoan(loan);
            if (resp != null)
            {
                LoanAmount = 0;
                LoanDuration=0;
                RateOfInterest= 0;
                date= DateTime.Now;
            }

        }

    }
}
