﻿using BankManagementSystem.Model;
using BankManagementSystem.View;
using BankManagementSystem.ViewModel.Command;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankManagementSystem.ViewModel
{
    public class UserVM : INotifyPropertyChanged
    {
        private BaseVM _selectedVM;

        public BaseVM selectedVM
        {
            get { return selectedVM; }
            set { selectedVM = value; }
        }

        private User user;
        public UserCommand userCommand;
        public User User
        {
            get { return user; }
            set
            {
                user = value;
                OnPropertyChanged(nameof(User));
                OnPropertyChanged(nameof(User.Address));
                OnPropertyChanged(nameof(User.Name));
                OnPropertyChanged(nameof(User.UserName));
                OnPropertyChanged(nameof(User.Password));

            }
        }
        public UserVM() { }

        public UserVM(User users)
        {
            this.User = users;
        }

        public UserVM(UserCommand userCommand)
        {
            this.userCommand=userCommand;
        }



        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}