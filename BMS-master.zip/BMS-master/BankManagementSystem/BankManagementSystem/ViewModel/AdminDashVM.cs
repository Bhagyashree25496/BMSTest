﻿using BankManagementSystem.Model;
using BankManagementSystem.View;
using BankManagementSystem.ViewModel.AdminVM;
using BankManagementSystem.ViewModel.Command;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace BankManagementSystem.ViewModel
{
    public class AdminDashVM:BaseVM
    {
        private BaseVM _selecteVM = new AdminUserVM();
        public ICommand LogoutCommand { get; set; }
        public BaseVM SelectedVM
        {
            get { return _selecteVM; }
            set
            {
                _selecteVM = value;
                OnPropertyChanged(nameof(SelectedVM));
            }
        }

        public ICommand UpdateAdminViewCommand { get; set; }
        
        public AdminDashVM()
        {
            UpdateAdminViewCommand = new UpdateAdminViewCommand(this);
            LogoutCommand = new LogoutCommand(this);
            
        }
        public event EventHandler Logouts;

        public async void Logout(User user)
        {
            Login login = new Login();
            login.Show();
            AdminView adminView= new AdminView();
            adminView.Hide();
            Application.Current.MainWindow.Show();
            Application.Current.Windows[0].Close();
        }
    }
}
