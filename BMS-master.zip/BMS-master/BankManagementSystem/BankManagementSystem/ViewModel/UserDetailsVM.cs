﻿using BankManagementSystem.Model;
using BankManagementSystem.ViewModel.Command;
using BankManagementSystem.ViewModel.Helper;
using CS.ViewModel.Handler;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace BankManagementSystem.ViewModel
{
    public class UserDetailsVM:BaseVM
    {
        public ICommand UpdateUserCommand { get; set; }
        private User userDetails;
        public DateTime CurrentDate= DateTime.Now;
        public User UserDetails
        {
            get { return userDetails; }
            set
            {
                userDetails = value;
                OnPropertyChanged(nameof(UserDetails));
            }
        }

        private string username;
        public string Username
        {
            get { return username; }
            set
            {
                username = value;
                OnPropertyChanged(nameof(Username));
            }
        }

        private string password;
        public string Password
        {
            get { return password; }
            set
            {
                password = value;
                OnPropertyChanged("Password");
            }
        }

        private string name;
        public string Name
        {
            get { return name; }
            set
            {
                name = value;
                OnPropertyChanged(nameof(Name));
            }
        }

        private string address;
        public string Address
        {
            get { return address; }
            set
            {
                address = value;
                OnPropertyChanged("Address");
            }
        }

        private string state;
        public string State
        {
            get { return state; }
            set
            {
                state = value;
                OnPropertyChanged("State");
            }
        }

        private string county;
        public string County
        {
            get { return county; }
            set
            {
                county = value;
                OnPropertyChanged("County");
            }
        }

        private string pan;
        public string PAN
        {
            get { return pan; }
            set
            {
                pan = value;
                OnPropertyChanged("Pan");
            }
        }

        private string email;
        public string Email
        {
            get { return email; }
            set
            {
                email = value;
                OnPropertyChanged("Email");
            }
        }


        private DateTime dob;
        public DateTime DOB
        {
            get { return dob; }
            set
            {
                dob = value;
                OnPropertyChanged("DOB");
            }
        }

        private string accountType;
        public string AccountType
        {
            get { return accountType; }
            set
            {
                accountType = value;
                OnPropertyChanged("AccountType");
            }
        }

        
        private string contactNo;
        public string ContactNo
        {
            get { return contactNo; }
            set
            {
                contactNo = value;
                OnPropertyChanged(nameof(ContactNo));
            }
        }

        public ILoginHandler LoginHandler;
        
        public UserDetailsVM()
        {
            UpdateUserCommand = new UpdateUserCommand(this);
            LoginHandler = new LoginHandler();
            if(userDetails==null)
            this.GetUser();
        }

        public async void GetUser()
        {
            if(UserDate.UserID!=0)
            {
                UserDetails = await LoginHandler.GetUser(UserDate.UserID);
                Username = UserDetails.UserName;
                Name = UserDetails.Name;
                Password = UserDetails.Password;
                Address = UserDetails.Address;
                AccountType = UserDetails.AccountType;
                ContactNo = UserDetails.ContactNo;
                Email = UserDetails.Email;
                PAN = UserDetails.PAN;
                DOB = UserDetails.DOB;
                State = UserDetails.State;
                County = UserDetails.County;
            }
            
            
        }
        
        public async void UpdateUser(User user)
        {
            user.UserName = Username;
            user.Name= Name;
            user.Password= Password;
            user.State = State;
            user.County= County;
            user.Address = Address;
            user.AccountType = AccountType;
            user.ContactNo = ContactNo;
            user.Email = Email;
            user.PAN = PAN;
            user.DOB = DOB;
            
            var response = await LoginHandler.UpdateUser(user);
            if (response != null)
            {
                
                UserDetails = response;

            }

        }


    }
}
