﻿using BankManagementSystem.Model;
using BankManagementSystem.View;
using BankManagementSystem.ViewModel.Command;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows;

namespace BankManagementSystem.ViewModel
{
    public class UserDashVM:BaseVM
    {
		private BaseVM _selecteVM = new UserDetailsVM();

		public BaseVM SelectedVM
		{
			get { return _selecteVM; }
			set { 
				_selecteVM = value;
				OnPropertyChanged(nameof(SelectedVM));
				}
		}

		public ICommand UpdateViewCommand { get; set; }
        public ICommand LogoutCommand { get; set; }

        public UserDashVM()
		{
			UpdateViewCommand= new UpdateViewCommand(this);
            LogoutCommand = new LogoutCommand(this);
        }

        public async void Logout(User user)
        {
            Login login = new Login();
            login.Show();
            UserView adminView = new UserView();
            adminView.Hide();
            Application.Current.MainWindow.Show();
            Application.Current.Windows[0].Close();
        }
    }
}
