﻿using AuthAPIs.Models.Domain;
using AuthAPIs.Repository;
using Microsoft.AspNetCore.Mvc;

namespace AuthAPIs.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class LoanController : Controller
    {
        private readonly ILoanRepository loanRepository;
        public LoanController(ILoanRepository loanRepository)
        {
            this.loanRepository = loanRepository;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllLoan()
        {
            var user = await loanRepository.GetAllLoan();
            return Ok(user);
        }

        [HttpPost]
        public async Task<IActionResult> AddLoan(AuthAPIs.Models.DTO.LoanDTO dtoloan)
        {
            var loan = new Loan()
            {
                LoanAmount = dtoloan.LoanAmount,
                LoanType = dtoloan.LoanType,
                LoanDuration = dtoloan.LoanDuration,
                RateOfInterest = dtoloan.RateOfInterest,
                Date = dtoloan.Date,
                Comments= dtoloan.Comments,
                Status= dtoloan.Status,
                UserId=dtoloan.UserId

            };
            loan= await loanRepository.AddLoan(loan);
            return CreatedAtAction(nameof(GetAllLoan), loan);
        }
        
        [HttpGet]
        [Route("{userid}/{loanid}")]
        public async Task<IActionResult> GetLoanByID(int userid, int loanid)
        {
            var user = await loanRepository.GetLoan(userid, loanid);
            return Ok(user);
        }
        [HttpGet]
        [Route("{userid}")]
        public async Task<IActionResult> GetLoanByUserID(int userid)
        {
            var user = await loanRepository.GetLoanByUserID(userid);
            return Ok(user);
        }

        [HttpPut]
        public async Task<ActionResult> UpdateLoanStatus([FromBody] AuthAPIs.Models.DTO.LoanDTO dotuser)

        {
            var user = new Loan()
            {
                LoanAmount = dotuser.LoanAmount,
                LoanDuration = dotuser.LoanDuration,
                RateOfInterest = dotuser.RateOfInterest,
                Date = dotuser.Date,
                LoanId =dotuser.LoanId,
               Status = dotuser.Status,
                Comments = dotuser.Comments

            };
            var returnUser = await loanRepository.GetLoanAfterUpdate(user);

            return Ok(returnUser);
        }

    }
}
