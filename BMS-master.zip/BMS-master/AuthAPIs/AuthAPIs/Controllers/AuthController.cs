﻿using AuthAPIs.Models.Domain;
using AuthAPIs.Repository;
using Microsoft.AspNetCore.Mvc;


namespace AuthAPIs.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AuthController : Controller
    {
        private readonly IUserRepository userRepository;
        public AuthController(IUserRepository userRepository) { 
            this.userRepository = userRepository;
        }
        [HttpGet]   
        public async Task<IActionResult> GetAllUser()
        {
            var user= await userRepository.GetAllUser();
            return Ok(user);
        }

        [HttpGet]
        [Route("{userid}")]
        public async Task<IActionResult> GetUserByID(int userid)
        {
            var user = await userRepository.GetUser(userid);
            return Ok(user);
        }


        [HttpGet]
        [Route("{username}/{password}")]
        public async Task<IActionResult> GetUserAuth(string username,string password)
        {
            var user = await userRepository.GetUserAuth(username,password);
            return Ok(user);
        }

        [HttpPost]
        public async Task<IActionResult> AddUser(AuthAPIs.Models.DTO.UserDTO dotuser )      
        {
            var user = new User()
            {
                UserName = dotuser.UserName,
                Password = dotuser.Password,
                Email = dotuser.Email,
                Name= dotuser.Name,
                Address= dotuser.Address,
                State= dotuser.State,
                ContactNo=dotuser.ContactNo,
                County=dotuser.County,
                PAN=dotuser.PAN,
                AccountType=dotuser.AccountType,
                DOB=dotuser.DOB

            };
            await userRepository.AddUser(user);
            return CreatedAtAction(nameof(GetAllUser), user);
        }

        [HttpPut]
        public async Task<ActionResult> UpdateUser([FromBody] AuthAPIs.Models.DTO.UserDTO dotuser)

        {
            var user = new User()
            {
                UserId= dotuser.UserId,
                UserName = dotuser.UserName,
                Password = dotuser.Password,
                Email = dotuser.Email,
                Name = dotuser.Name,
                Address = dotuser.Address,
                State = dotuser.State,
                ContactNo = dotuser.ContactNo,
                County = dotuser.County,
                PAN = dotuser.PAN,
                AccountType = dotuser.AccountType,
                DOB = dotuser.DOB,
                
            };
             var returnUser= await userRepository.UpdateUser(user);

            return Ok(returnUser);
        }
        
    }
}
