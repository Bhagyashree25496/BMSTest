﻿using AuthAPIs.Models.Domain;

namespace AuthAPIs.Repository
{
    public interface ILoanRepository
    {
        Task<IEnumerable<Loan>> GetAllLoan();

        Task<Loan> GetLoan(int UserID, int LoanID);

        Task<IEnumerable<Loan>> GetLoanByUserID(int UserID);

        Task<Loan> AddLoan(Loan loan);

        Task<Loan> UpdateLoan(Loan loan);
        Task<IEnumerable<Loan>> GetLoanAfterUpdate(Loan loan);

    }
}
