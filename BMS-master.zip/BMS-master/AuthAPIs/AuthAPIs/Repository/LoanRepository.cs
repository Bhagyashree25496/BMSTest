﻿using AuthAPIs.Data;
using AuthAPIs.Models.Domain;
using Microsoft.EntityFrameworkCore;

namespace AuthAPIs.Repository
{
    public class LoanRepository : ILoanRepository
    {
        private readonly AuthDbContext authDbContext;
        public LoanRepository(AuthDbContext authDbContext)
        {
            this.authDbContext = authDbContext;
        }

        public async Task<IEnumerable<Loan>> GetAllLoan()
        {
            return authDbContext.Loans.Where(i => i.Status == "Active");
        }


        public async Task<Loan> GetLoan(int UserID, int LoanID)
        {
            return await authDbContext.Loans.FirstOrDefaultAsync(i => i.UserId == UserID && i.LoanId == LoanID);
        }

        

        public async Task<Loan> AddLoan(Loan loan)
        {
            await authDbContext.Loans.AddAsync(loan);
            await authDbContext.SaveChangesAsync();
            return null;
        }

        public async Task<Loan> UpdateLoan(Loan loan)
        {
            var existLoan = await authDbContext.Loans.FirstOrDefaultAsync(i => i.LoanId == loan.LoanId);
            if (existLoan == null)
            {
                return null;
            }
            existLoan.Status = loan.Status;
            existLoan.Comments = loan.Comments;

            await authDbContext.SaveChangesAsync();
            return existLoan;
        }

        public async Task<IEnumerable<Loan>> GetLoanByUserID(int UserID)
        {
            return authDbContext.Loans.Where(i => i.UserId == UserID );
        }

        public async Task<IEnumerable<Loan>> GetLoanAfterUpdate(Loan loan)
        {
            var existLoan = await authDbContext.Loans.FirstOrDefaultAsync(i => i.LoanId == loan.LoanId);
            if (existLoan == null)
            {
                return null;
            }
            existLoan.Status = loan.Status;
            existLoan.Comments = loan.Comments;

            await authDbContext.SaveChangesAsync();
            return authDbContext.Loans.Where(i => i.Status == "Active");
        }
    }
}
