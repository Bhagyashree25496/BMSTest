﻿using AuthAPIs.Models.Domain;

namespace AuthAPIs.Repository
{
    public interface IUserRepository
    {
        Task<IEnumerable<User>> GetAllUser();
        Task<User> GetUserAuth(string username, string password);

        Task<User> GetUser(int userID);

        
        
        Task<User> AddUser(User user);
        
        Task<User> UpdateUser (User user);
        


    }
}
