﻿using AuthAPIs.Data;
using AuthAPIs.Models.Domain;
using Microsoft.EntityFrameworkCore;

namespace AuthAPIs.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly AuthDbContext authDbContext;
        public UserRepository(AuthDbContext authDbContext)
        {
            this.authDbContext = authDbContext;
        }

        public async Task<User> AddUser(User user)
        {
            var existingUsername = await authDbContext.Users.FirstOrDefaultAsync(i => i.UserName == user.UserName);
            if (existingUsername != null)
            {
                return null;
            }
            else
            {
                user.Role = "C";
                await authDbContext.Users.AddAsync(user);
                await authDbContext.SaveChangesAsync();
                return user;
            }
            
        }

        public async Task<IEnumerable<User>> GetAllUser()
        {
            return  await authDbContext.Users.ToListAsync();
        }

        
        public async Task<User> GetUser(int userID)
        {
            return await authDbContext.Users.FirstOrDefaultAsync(i => i.UserId == userID);
        }

        public async Task<User> GetUserAuth(string username, string password)
        {
            return await  authDbContext.Users.FirstOrDefaultAsync(u=>u.UserName.Equals(username) && u.Password.Equals(password));
        
        }

        
        public async Task<User> UpdateUser(User user)
        {
            var existingUser = await authDbContext.Users.FirstOrDefaultAsync(i=>i.UserId== user.UserId);
            if(existingUser == null) {
                return null;
            }

            existingUser.Name = user.Name;
            existingUser.UserName = user.UserName;
            existingUser.Password = user.Password;
            existingUser.Address = user.Address;
            existingUser.State = user.State;
            existingUser.County= user.County;
            existingUser.PAN = user.PAN; 
            existingUser.Email = user.Email;
            existingUser.DOB = user.DOB;
            existingUser.AccountType= user.AccountType;
            existingUser.ContactNo= user.ContactNo;
            
            await authDbContext.SaveChangesAsync();

            return user;







        }
    }
}
