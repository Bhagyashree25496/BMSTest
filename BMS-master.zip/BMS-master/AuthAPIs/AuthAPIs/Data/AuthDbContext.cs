﻿using AuthAPIs.Models.Domain;
using Microsoft.EntityFrameworkCore;

namespace AuthAPIs.Data
{
    public class AuthDbContext : DbContext
    {
        public AuthDbContext()
        {

        }
        public AuthDbContext(DbContextOptions<AuthDbContext> options):base(options)
        {

        }
        public virtual DbSet<Loan> Loans { get; set; }

        public virtual DbSet<User> Users { get; set; }


    }
}
