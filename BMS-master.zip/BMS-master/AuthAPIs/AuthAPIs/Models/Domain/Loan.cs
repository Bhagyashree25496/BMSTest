﻿namespace AuthAPIs.Models.Domain
{
    public class Loan
    {
        public int LoanId { get; set; }
        public int UserId { get; set; }

        public string LoanType { get; set; }
        public double LoanAmount { get; set; }
        public DateTime Date { get; set; }
        public int RateOfInterest { get; set; }
        public int LoanDuration { get; set; }

        public string Comments { get; set; }
        public string Status { get; set; }

        public User User { get; set; }
    }
}
