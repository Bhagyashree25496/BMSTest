﻿using AuthAPIs.Data;
using AuthAPIs.Models.Domain;
using AuthAPIs.Models.DTO;
using AuthAPIs.Repository;
using Microsoft.EntityFrameworkCore;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AuthAPIS.Tests
{
    [TestFixture]
    public class LoanReposTest
    {
        private List<Loan> loanDetail_list = new List<Loan>() { TestData.Loan };
        private Mock<AuthDbContext> mockBankDbContext;
        private Mock<DbSet<Loan>> mockLoanDetailDbSet;
        private ILoanRepository applyLoanRepositry;
        public LoanReposTest()
        {
           
        }

        [SetUp]
        public void Setup()
        {
            var data = loanDetail_list.AsQueryable();
            mockBankDbContext = new Mock<AuthDbContext>();
            mockLoanDetailDbSet = new Mock<DbSet<Loan>>();
            mockLoanDetailDbSet.As<IQueryable<Loan>>().Setup(m => m.Provider).Returns(data.Provider);
            mockLoanDetailDbSet.As<IQueryable<Loan>>().Setup(m => m.ElementType).Returns(data.ElementType);
            mockLoanDetailDbSet.As<IQueryable<Loan>>().Setup(m => m.Expression).Returns(data.Expression);
            mockLoanDetailDbSet.As<IQueryable<Loan>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());
            mockBankDbContext.Setup(x=>x.Loans ).Returns(mockLoanDetailDbSet.Object);
            //mockBankDbContext=new Mock<AuthDbContext>();
            applyLoanRepositry = new LoanRepository(mockBankDbContext.Object);
        }

        [Test]
        public void GetLoanAsync_Test()
        {
            int loanId = loanDetail_list.FirstOrDefault().LoanId;
            int userId = loanDetail_list.FirstOrDefault().UserId;

            var res = applyLoanRepositry.GetLoanByUserID(userId);

            Assert.IsTrue(res.IsCompleted);
        }









    }
}
