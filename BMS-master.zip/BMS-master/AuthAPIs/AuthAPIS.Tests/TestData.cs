﻿using AuthAPIs.Models.Domain;
using AuthAPIs.Models.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AuthAPIS.Tests
{
    public class TestData
    {
        private static User userDetail;

        public static User UserDetail
        {
            get
            {
                userDetail = new User()
                {
                    UserId = 1,
                    Name = "Bhagyashree",
                    UserName = "Bhagu1996",
                    Password = "Bhagu@1996",
                    Address = "kyn",
                    State = "mh",
                    County = "ind",
                    PAN = "qqqqeeee11",
                    Email = "abc@abc.com",
                    DOB = DateTime.Now,
                    AccountType = "Saving Account",
                    ContactNo = "9423085884"
                };
                return userDetail;
            }

        }

        private static UserDTO userDTO;

        public static UserDTO UserDTO
        {
            get
            {
                userDTO = new UserDTO()
                {
                    UserId = 1,
                    Name = "Bhagyashree",
                    UserName = "Bhagu1996",
                    Password = "Bhagu@1996",
                    Address = "kyn",
                    State = "mh",
                    County = "ind",
                    PAN = "qqqqeeee11",
                    Email = "abc@abc.com",
                    DOB = DateTime.Now,
                    AccountType = "Saving Account",
                    ContactNo = "9423085884"
                };
                return userDTO;
            }

        }


        private static Loan loan;

        public static Loan Loan
        {
            get
            {
                loan = new Loan()
                {
                    LoanType = "Home Loan",
                    LoanAmount = 200000,
                    LoanDuration = 7,
                    UserId = 1,
                    LoanId = 1,
                    Date = DateTime.Now,
                    RateOfInterest = 10,
                    Comments = "test",
                    Status = "Active"
                };
                return loan;
            }

        }
        private static LoanDTO loanDTO;

        public static LoanDTO LoanDTO
        {
            get
            {
                loanDTO = new LoanDTO()
                {
                    LoanType = "Home Loan",
                    LoanAmount = 200000,
                    LoanDuration = 7,
                    UserId = 1,
                    LoanId = 1,
                    Date = DateTime.Now,
                    RateOfInterest = 10,
                    Comments = "test",
                    Status = "Active"
                };
                return loanDTO;
            }

        }

    }
}
