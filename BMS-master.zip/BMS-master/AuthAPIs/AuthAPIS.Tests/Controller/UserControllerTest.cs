﻿using AuthAPIs.Controllers;
using AuthAPIs.Models.Domain;
using AuthAPIs.Models.DTO;
using AuthAPIs.Repository;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AuthAPIS.Tests.Controller
{
    public class UserControllerTest
    {
        private Mock<IUserRepository> UserRepository;
        private AuthController UserController;
        private User user;
        private UserDTO userDTO;


        public UserControllerTest()
        {
            user = TestData.UserDetail;
            userDTO=TestData.UserDTO;

        }

        [SetUp]
        public void Setup()
        {
            UserRepository = new Mock<IUserRepository>();
            UserController = new AuthController(UserRepository.Object);
        }

        [Test]
        public void getAllUser_Test()
        {
            UserRepository.Setup(x => x.GetAllUser())
                .ReturnsAsync(new List<User>() { 
                new User()
                {
                    UserId = user.UserId,
                    Name = user.Name,
                    UserName = user.UserName,
                    Password = user.Password,
                    Address = user.Address,
                    State = user.State,
                    County = user.County,
                    PAN = user.PAN,
                    Email = user.Email,
                    DOB = user.DOB,
                    AccountType = user.AccountType,
                    ContactNo = user.ContactNo
                }
                });

            _=UserController.GetAllUser();

            UserRepository.Verify(x=>x.GetAllUser(), Times.Once());
        }

        [Test]
        public void GetUserByID_Test()
        {
            UserRepository.Setup(x => x.GetUser(It.IsAny<int>()))
                .ReturnsAsync(
                new User()
                {
                    UserId = user.UserId,
                    Name = user.Name,
                    UserName = user.UserName,
                    Password = user.Password,
                    Address = user.Address,
                    State = user.State,
                    County = user.County,
                    PAN = user.PAN,
                    Email = user.Email,
                    DOB = user.DOB,
                    AccountType = user.AccountType,
                    ContactNo = user.ContactNo
                });

            _=UserController.GetUserByID(user.UserId);

            UserRepository.Verify(x => x.GetUser(user.UserId), Times.Once());
        }

        [Test]
        public void GetUserAuth_Test()
        {
            UserRepository.Setup(x => x.GetUserAuth(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(
                new User()
                {
                    UserId = user.UserId,
                    Name = user.Name,
                    UserName = user.UserName,
                    Password = user.Password,
                    Address = user.Address,
                    State = user.State,
                    County = user.County,
                    PAN = user.PAN,
                    Email = user.Email,
                    DOB = user.DOB,
                    AccountType = user.AccountType,
                    ContactNo = user.ContactNo
                });

            _=UserController.GetUserAuth(user.UserName,user.Password);

            UserRepository.Verify(x => x.GetUserAuth(user.UserName,user.Password), Times.Once());
        }

        [Test]
        public void AddUser_Test()
        {
            UserRepository.Setup(x => x.AddUser(It.IsAny<User>()))
                .ReturnsAsync(
                new User()
                {
                    UserId = user.UserId,
                    Name = user.Name,
                    UserName = user.UserName,
                    Password = user.Password,
                    Address = user.Address,
                    State = user.State,
                    County = user.County,
                    PAN = user.PAN,
                    Email = user.Email,
                    DOB = user.DOB,
                    AccountType = user.AccountType,
                    ContactNo = user.ContactNo
                });

            var result=UserController.AddUser(userDTO);

            Assert.AreEqual(true, result.IsCompleted);
        }

        [Test]
        public void UpdateUser_Test()
        {
            UserRepository.Setup(x => x.UpdateUser(It.IsAny<User>()))
                .ReturnsAsync(
                new User()
                {
                    UserId = user.UserId,
                    Name = user.Name,
                    UserName = user.UserName,
                    Password = user.Password,
                    Address = user.Address,
                    State = user.State,
                    County = user.County,
                    PAN = user.PAN,
                    Email = user.Email,
                    DOB = user.DOB,
                    AccountType = user.AccountType,
                    ContactNo = user.ContactNo
                });

            var result = UserController.UpdateUser(userDTO);

            Assert.AreEqual(true, result.IsCompleted);
        }


    }
}
