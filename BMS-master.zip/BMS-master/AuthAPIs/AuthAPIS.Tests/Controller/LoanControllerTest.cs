﻿using AuthAPIs.Controllers;
using AuthAPIs.Models.Domain;
using AuthAPIs.Models.DTO;
using AuthAPIs.Repository;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AuthAPIS.Tests.Controller
{
    public class LoanControllerTest
    {
        private Mock<ILoanRepository> LoanRepository;
        private LoanController LoanController;
        private Loan loanDetail;
        private LoanDTO loanDTO;
        

        public LoanControllerTest()
        {
            loanDetail = TestData.Loan;
            loanDTO=TestData.LoanDTO;

        }

        [SetUp]
        public void Setup()
        {
            LoanRepository = new Mock<ILoanRepository>();
            LoanController = new LoanController(LoanRepository.Object);
        }

        [Test]
        public void GetLoanByUserID_Test()
        {
            LoanRepository.Setup(x => x.GetLoanByUserID(It.IsAny<int>()))
                .ReturnsAsync(new List<Loan>()
                {new Loan(){
                    LoanId = loanDetail.LoanId,
                    LoanAmount = loanDetail.LoanAmount,
                    Date = loanDetail.Date,
                    LoanDuration = loanDetail.LoanDuration,
                    LoanType = loanDetail.LoanType,
                    Comments = loanDetail.Comments,
                    RateOfInterest = loanDetail.RateOfInterest,
                    Status = loanDetail.Status }
                });

            
            _ = LoanController.GetLoanByUserID(loanDetail.LoanId);
            LoanRepository.Verify(x => x.GetLoanByUserID(loanDetail.UserId), Times.Once);
        }

        [Test]
        public void GetAllLoan_Test()
        {
            LoanRepository.Setup(x => x.GetAllLoan())
                .ReturnsAsync(new List<Loan>()
                {new Loan(){
                    LoanId = loanDetail.LoanId,
                    LoanAmount = loanDetail.LoanAmount,
                    Date = loanDetail.Date,
                    LoanDuration = loanDetail.LoanDuration,
                    LoanType = loanDetail.LoanType,
                    Comments = loanDetail.Comments,
                    RateOfInterest = loanDetail.RateOfInterest,
                    Status = loanDetail.Status }
                });


            var res = LoanController.GetAllLoan();
            Assert.AreEqual(true, res.IsCompleted);
        }

        [Test]
        public void GetLoan_Test()
        {
            LoanRepository.Setup(x => x.GetLoan(It.IsAny<int>(), It.IsAny<int>()))
                .ReturnsAsync(new Loan(){
                    LoanId = loanDetail.LoanId,
                    LoanAmount = loanDetail.LoanAmount,
                    Date = loanDetail.Date,
                    LoanDuration = loanDetail.LoanDuration,
                    LoanType = loanDetail.LoanType,
                    Comments = loanDetail.Comments,
                    RateOfInterest = loanDetail.RateOfInterest,
                    Status = loanDetail.Status 
                });


            var res = LoanController.GetLoanByID(loanDetail.UserId,loanDetail.LoanId);
            LoanRepository.Verify(x => x.GetLoan(loanDetail.UserId, loanDetail.LoanId), Times.Once);
        }

        [Test]
        public void UpdateLoan_Test()
        {
            LoanRepository.Setup(x => x.UpdateLoan(It.IsAny<Loan>()))
                .ReturnsAsync(new Loan()
                {
                    LoanId = loanDetail.LoanId,
                    LoanAmount = loanDetail.LoanAmount,
                    Date = loanDetail.Date,
                    LoanDuration = loanDetail.LoanDuration,
                    LoanType = loanDetail.LoanType,
                    Comments = loanDetail.Comments,
                    RateOfInterest = loanDetail.RateOfInterest,
                    Status = loanDetail.Status
                });

            var res = LoanController.UpdateLoanStatus(loanDTO);

            Assert.AreEqual(true, res.IsCompleted);

        }

        [Test]
        public void AddLoan_Test()
        {
            LoanRepository.Setup(x => x.AddLoan(It.IsAny<Loan>()))
                .ReturnsAsync(new Loan()
                {
                    LoanId = loanDetail.LoanId,
                    LoanAmount = loanDetail.LoanAmount,
                    Date = loanDetail.Date,
                    LoanDuration = loanDetail.LoanDuration,
                    LoanType = loanDetail.LoanType,
                    Comments = loanDetail.Comments,
                    RateOfInterest = loanDetail.RateOfInterest,
                    Status = loanDetail.Status
                });

            var res = LoanController.AddLoan(loanDTO);

            Assert.AreEqual(true, res.IsCompleted);

        }

    }
}
